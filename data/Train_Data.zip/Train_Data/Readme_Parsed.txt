This outlines the rgb code for each of the parsed components.

legs        [0,255,0]
shoes       [0,0,255]
torso       [255,0,0]
luggage     [255,255,0]
skin_legs   [255,0,255]
skin_arms   [0,255,255]
skin_face   [255,125,0]
hair        [0,125,255]

All the binary masks are three dimensional and each dimension is equal to all the others.